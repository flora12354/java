-- ============================================================
-- Hello Kitty 登录系统 - 数据库初始化脚本
-- 数据库：MySQL 8.0+
-- 用法：mysql -uroot -p123456 < hellokitty_login.sql
-- ============================================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS hellokitty_login
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

USE hellokitty_login;

-- 用户表
DROP TABLE IF EXISTS user;
CREATE TABLE user (
  id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  username    VARCHAR(50)  NOT NULL                COMMENT '用户名',
  password    VARCHAR(64)  NOT NULL                COMMENT '密码（MD5加密存储）',
  create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (id),
  UNIQUE KEY uk_username (username)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '用户表';

-- 测试账号：admin / 123456（密码为 MD5 加密后的值）
INSERT INTO user (username, password)
VALUES ('admin', MD5('123456'));
